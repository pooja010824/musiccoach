# MusicCoach final deployment checklist

## Included in this package
- Prisma 7 configuration with `tsx prisma/seed.js` registered as the seed command.
- Production build runs Prisma generate, migrations, idempotent demo seed, and Vite build.
- Demo coaches: Rahul Sharma (Piano), Priya Mehta (Violin), Ananya Verma (Vocal).
- Public coach API does not expose password hashes or other private user fields.
- Authenticated booking/payment/dashboard data remains user-scoped.
- Cancelled bookings are excluded from active dashboard totals and paid totals.
- Source UI text is UTF-8 and does not contain the earlier mojibake sequences.

## Render
Set these environment variables in the Render service:
- `DATABASE_URL=file:./dev.db`
- `JWT_SECRET=<strong-random-secret>`

Build command:
`npm install --include=dev && npm run build`

Start command:
`npm start`

The build command automatically runs:
1. `prisma generate`
2. `prisma migrate deploy`
3. `prisma db seed`
4. `vite build`

After deployment, verify:
1. `/api/health` returns success.
2. Home page shows 3 coaches.
3. Find a Coach filters Piano/Violin/Vocal.
4. Sign up/login works.
5. Booking and payment work for the logged-in student.
6. Dashboard only shows that student's private records.
7. Logout clears private dashboard state.
