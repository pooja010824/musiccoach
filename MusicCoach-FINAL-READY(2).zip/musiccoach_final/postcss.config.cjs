﻿module.exports = {
  plugins: {}
};
